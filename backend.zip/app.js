const express = require('express');
const cors = require('cors');

const indexRouter = require('./routes/index');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use('/', indexRouter);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Backend is now listening on port ${PORT}!`);
    console.log(`For API docs, navigate to http://localhost:${PORT}`);
});


