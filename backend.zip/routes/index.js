const express = require('express');
const request = require("request");
const router = express.Router();
const moment = require('moment');

const WEATHER_APIKEY = "gDvrWkRKh4ZX2arUqIPRnLN9g2YiBDCw";
const GOOGLEMAP_APIKEY = "AIzaSyAmq6zgFx8wkyhYjc1nbUZ6qbIO7hMf4UY"
const GEOCODE_APIKEY = "AIzaSyD4uhd9rjONfLoBlXjYBg_pVv3ywP2XFg8"

const WEATHER_FIELDS = ['temperature', 'temperatureApparent', 'temperatureMin', 'temperatureMax', 'windSpeed',
    'windDirection', 'humidity', 'pressureSeaLevel', 'weatherCode', 'precipitationProbability',
    'precipitationType', 'sunriseTime', 'sunsetTime', 'visibility', 'moonPhase', 'cloudCover', 'weatherCode']
const STATE = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AS": "American Samoa",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "DC": "District Of Columbia",
    "FM": "Federated States Of Micronesia",
    "FL": "Florida",
    "GA": "Georgia",
    "GU": "Guam",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "ME": "Maine",
    "MH": "Marshall Islands",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "MP": "Northern Mariana Islands",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PW": "Palau",
    "PA": "Pennsylvania",
    "PR": "Puerto Rico",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VI": "Virgin Islands",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming"
};
const WEATHER_CODE_DICT = {
    '0': {'text': 'Unknown', 'code': 'unknown'},
    '1000': {'text': 'Clear', 'code': 'clear_day'},
    '1001': {'text': 'Cloudy', 'code': 'cloudy'},
    '1100': {'text': 'Mostly Clear', 'code': 'mostly_clear_day'},
    '1101': {'text': 'Partly Cloudy', 'code': 'partly_cloudy_day'},
    '1102': {'text': 'Mostly Cloudy', 'code': 'mostly_cloudy'},
    '2000': {'text': 'Fog', 'code': 'fog'},
    '2100': {'text': 'Light Fog', 'code': 'fog_light'},
    '3000': {'text': 'Light Wind', 'code': 'light_wind'},
    '3001': {'text': 'Wind', 'code': 'wind'},
    '3002': {'text': 'Strong Wind', 'code': 'strong_wind'},
    '4000': {'text': 'Drizzle', 'code': 'drizzle'},
    '4001': {'text': 'Rain', 'code': 'rain'},
    '4200': {'text': 'Light Rain', 'code': 'rain_light'},
    '4201': {'text': 'Heavy Rain', 'code': 'rain_heavy'},
    '5000': {'text': 'Snow', 'code': 'snow'},
    '5001': {'text': 'Flurries', 'code': 'flurries'},
    '5100': {'text': 'Light Snow', 'code': 'snow_light'},
    '5101': {'text': 'Heavy Snow', 'code': 'snow_heavy'},
    '6000': {'text': 'Freezing Drizzle', 'code': 'freezing_drizzle'},
    '6001': {'text': 'Freezing Rain', 'code': 'freezing_rain'},
    '6200': {'text': 'Freezing Rain Light', 'code': 'freezing_rain_light'},
    '6201': {'text': 'Freezing Rain Heavy', 'code': 'freezing_rain_heavy'},
    '7000': {'text': 'Ice Pellets', 'code': 'ice_pellets'},
    '7101': {'text': 'Ice Pellets Heavy', 'code': 'ice_pellets_heavy'},
    '7102': {'text': 'Ice Pellets Light', 'code': 'ice_pellets_light'},
    '8000': {'text': 'Thunderstorm', 'code': 'thunderstorm'}
}
const testWeatherData = [
    {
        "startTime": "Saturday, 6 November 2021",
        "values": {
            "temperature": 66.2,
            "temperatureApparent": 66.2,
            "temperatureMin": 55.96,
            "temperatureMax": 66.2,
            "windSpeed": 7,
            "windDirection": 198.27,
            "humidity": 92.96,
            "pressureSeaLevel": 30,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-06T07:18:20-07:00",
            "sunsetTime": "2021-11-06T17:55:00-07:00",
            "visibility": 9.94,
            "moonPhase": 0,
            "cloudCover": 100
        },
        "timestamp": 1636203600000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Sunday, 0 November 2021",
        "values": {
            "temperature": 69.42,
            "temperatureApparent": 69.42,
            "temperatureMin": 53.83,
            "temperatureMax": 69.42,
            "windSpeed": 8.59,
            "windDirection": 140.08,
            "humidity": 99.89,
            "pressureSeaLevel": 29.99,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-07T06:18:20-08:00",
            "sunsetTime": "2021-11-07T16:55:00-08:00",
            "visibility": 9.94,
            "moonPhase": 1,
            "cloudCover": 100
        },
        "timestamp": 1636290000000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Monday, 1 November 2021",
        "values": {
            "temperature": 72.97,
            "temperatureApparent": 72.97,
            "temperatureMin": 53.17,
            "temperatureMax": 72.97,
            "windSpeed": 9.73,
            "windDirection": 140.95,
            "humidity": 99.79,
            "pressureSeaLevel": 30,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 1,
            "sunriseTime": "2021-11-08T06:20:00-08:00",
            "sunsetTime": "2021-11-08T16:53:20-08:00",
            "visibility": 9.94,
            "moonPhase": 1,
            "cloudCover": 100
        },
        "timestamp": 1636376400000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Tuesday, 2 November 2021",
        "values": {
            "temperature": 68.32,
            "temperatureApparent": 68.32,
            "temperatureMin": 52.14,
            "temperatureMax": 68.32,
            "windSpeed": 12.95,
            "windDirection": 166.15,
            "humidity": 99.22,
            "pressureSeaLevel": 30.12,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 1,
            "sunriseTime": "2021-11-09T06:20:00-08:00",
            "sunsetTime": "2021-11-09T16:53:20-08:00",
            "visibility": 9.94,
            "moonPhase": 1,
            "cloudCover": 100
        },
        "timestamp": 1636462800000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Wednesday, 3 November 2021",
        "values": {
            "temperature": 82.9,
            "temperatureApparent": 80.71,
            "temperatureMin": 58.12,
            "temperatureMax": 82.9,
            "windSpeed": 14.41,
            "windDirection": 256.58,
            "humidity": 89.17,
            "pressureSeaLevel": 29.94,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-10T06:21:40-08:00",
            "sunsetTime": "2021-11-10T16:51:40-08:00",
            "visibility": 15,
            "moonPhase": 2,
            "cloudCover": 41.67
        },
        "timestamp": 1636549200000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }, {
        "startTime": "Thursday, 4 November 2021",
        "values": {
            "temperature": 84.51,
            "temperatureApparent": 81.88,
            "temperatureMin": 66.4,
            "temperatureMax": 84.51,
            "windSpeed": 8.17,
            "windDirection": 218.61,
            "humidity": 47.26,
            "pressureSeaLevel": 29.95,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-11T06:21:40-08:00",
            "sunsetTime": "2021-11-11T16:51:40-08:00",
            "visibility": 15,
            "moonPhase": 2,
            "cloudCover": 6.09
        },
        "timestamp": 1636635600000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }, {
        "startTime": "Friday, 5 November 2021",
        "values": {
            "temperature": 86.23,
            "temperatureApparent": 82.89,
            "temperatureMin": 69.67,
            "temperatureMax": 86.23,
            "windSpeed": 7.67,
            "windDirection": 209.61,
            "humidity": 19.46,
            "pressureSeaLevel": 30.01,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-12T06:23:20-08:00",
            "sunsetTime": "2021-11-12T16:51:40-08:00",
            "visibility": 15,
            "moonPhase": 2,
            "cloudCover": 100
        },
        "timestamp": 1636722000000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }, {
        "startTime": "Saturday, 6 November 2021",
        "values": {
            "temperature": 83.84,
            "temperatureApparent": 81.25,
            "temperatureMin": 69.46,
            "temperatureMax": 83.84,
            "windSpeed": 6.82,
            "windDirection": 164.76,
            "humidity": 25.49,
            "pressureSeaLevel": 29.97,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-13T06:23:20-08:00",
            "sunsetTime": "2021-11-13T16:50:00-08:00",
            "visibility": 15,
            "moonPhase": 2,
            "cloudCover": 95.37
        },
        "timestamp": 1636808400000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Sunday, 0 November 2021",
        "values": {
            "temperature": 78.73,
            "temperatureApparent": 78.73,
            "temperatureMin": 67.06,
            "temperatureMax": 78.73,
            "windSpeed": 6.62,
            "windDirection": 179.59,
            "humidity": 28.98,
            "pressureSeaLevel": 29.95,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-14T06:23:20-08:00",
            "sunsetTime": "2021-11-14T16:48:20-08:00",
            "visibility": 15,
            "moonPhase": 3,
            "cloudCover": 100
        },
        "timestamp": 1636894800000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Monday, 1 November 2021",
        "values": {
            "temperature": 75.24,
            "temperatureApparent": 75.24,
            "temperatureMin": 65.82,
            "temperatureMax": 75.24,
            "windSpeed": 7.9,
            "windDirection": 179.11,
            "humidity": 49.2,
            "pressureSeaLevel": 29.98,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-15T06:26:40-08:00",
            "sunsetTime": "2021-11-15T16:48:20-08:00",
            "visibility": 15,
            "moonPhase": 3,
            "cloudCover": 100
        },
        "timestamp": 1636981200000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Tuesday, 2 November 2021",
        "values": {
            "temperature": 71.89,
            "temperatureApparent": 71.89,
            "temperatureMin": 62.74,
            "temperatureMax": 71.89,
            "windSpeed": 8.43,
            "windDirection": 193.66,
            "humidity": 56.05,
            "pressureSeaLevel": 29.99,
            "weatherCode": 1001,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-16T06:26:40-08:00",
            "sunsetTime": "2021-11-16T16:48:20-08:00",
            "visibility": 15,
            "moonPhase": 3,
            "cloudCover": 100
        },
        "timestamp": 1637067600000,
        "weather": "cloudy",
        "weatherStatus": "Cloudy"
    }, {
        "startTime": "Wednesday, 3 November 2021",
        "values": {
            "temperature": 72.05,
            "temperatureApparent": 72.05,
            "temperatureMin": 61.74,
            "temperatureMax": 72.05,
            "windSpeed": 9.26,
            "windDirection": 192.42,
            "humidity": 61.15,
            "pressureSeaLevel": 29.99,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-17T06:28:20-08:00",
            "sunsetTime": "2021-11-17T16:48:20-08:00",
            "visibility": 15,
            "moonPhase": 4,
            "cloudCover": 76.88
        },
        "timestamp": 1637154000000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }, {
        "startTime": "Thursday, 4 November 2021",
        "values": {
            "temperature": 73.04,
            "temperatureApparent": 73.04,
            "temperatureMin": 62.4,
            "temperatureMax": 73.04,
            "windSpeed": 6.51,
            "windDirection": 160.86,
            "humidity": 54.55,
            "pressureSeaLevel": 30.02,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-18T06:28:20-08:00",
            "sunsetTime": "2021-11-18T16:46:40-08:00",
            "visibility": 15,
            "moonPhase": 4,
            "cloudCover": 82.9
        },
        "timestamp": 1637240400000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }, {
        "startTime": "Friday, 5 November 2021",
        "values": {
            "temperature": 78.24,
            "temperatureApparent": 78.24,
            "temperatureMin": 65.93,
            "temperatureMax": 78.24,
            "windSpeed": 7.43,
            "windDirection": 179.12,
            "humidity": 35.1,
            "pressureSeaLevel": 30,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-19T06:28:20-08:00",
            "sunsetTime": "2021-11-19T16:46:40-08:00",
            "visibility": 15,
            "moonPhase": 4,
            "cloudCover": 100
        },
        "timestamp": 1637326800000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }, {
        "startTime": "Saturday, 6 November 2021",
        "values": {
            "temperature": 78.91,
            "temperatureApparent": 78.91,
            "temperatureMin": 66.67,
            "temperatureMax": 78.91,
            "windSpeed": 7.7,
            "windDirection": 170.97,
            "humidity": 40.27,
            "pressureSeaLevel": 29.93,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-20T06:30:00-08:00",
            "sunsetTime": "2021-11-20T16:46:40-08:00",
            "visibility": 15,
            "moonPhase": 4,
            "cloudCover": 100
        },
        "timestamp": 1637413200000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }, {
        "startTime": "Sunday, 0 November 2021",
        "values": {
            "temperature": 79.02,
            "temperatureApparent": 78.46,
            "temperatureMin": 66.61,
            "temperatureMax": 79.02,
            "windSpeed": 6.24,
            "windDirection": 203.7,
            "humidity": 35.82,
            "pressureSeaLevel": 29.9,
            "weatherCode": 1000,
            "precipitationProbability": 0,
            "precipitationType": 0,
            "sunriseTime": "2021-11-21T06:30:00-08:00",
            "sunsetTime": "2021-11-21T16:46:40-08:00",
            "visibility": 15,
            "moonPhase": 4,
            "cloudCover": 10.44
        },
        "timestamp": 1637499600000,
        "weather": "clear_day",
        "weatherStatus": "Clear"
    }]

function requests(options) {
    return new Promise((resolve, reject) => {
        request(options, function (error, response, body) {
            if (!error && response.statusCode === 200) {
                resolve(body)
            } else {
                reject(body)
            }
        });
    });
}

function autoComplete(input) {
    let url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${input}&types=(cities)&components=country:us&key=${GOOGLEMAP_APIKEY}`;
    return requests({
        url,
        method: "GET",
        json: true,
        headers: {"Accept": "application/json"},
    })
}

function getLocation(street, city, state) {
    let address = `${street} ${city} ${state}`.replace(/\s+/g, "+");
    let url = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${GEOCODE_APIKEY}`
    return requests({
        url,
        method: "GET",
        json: true,
        headers: {"Accept": "application/json"},
    })
}

function handleData(response) {
    const timeline = response.data.timelines[0];
    timeline.intervals.forEach(item => {
        item.timestamp = moment(item.startTime).unix() * 1000;
        item.startTime = moment(item.startTime).format("dddd, DD MMM YYYY");
        if (item.values.weatherCode) {
            let w_code = item.values.weatherCode;
            item.weather = WEATHER_CODE_DICT[w_code].code;
            item.weatherStatus = WEATHER_CODE_DICT[w_code].text
        }
    })
    return timeline
}

function getWeather(longitude, latitude, timeStep = '1d', fields) {
    let url = "https://api.tomorrow.io/v4/timelines";
    let querystring = {
        "units": "imperial",
        "timesteps": timeStep,
        "timezone": "America/Los_Angeles",
        "apikey": WEATHER_APIKEY,
        "location": `${latitude},${longitude}`,
        "fields": fields
    }
    return requests({
        url,
        method: "GET",
        headers: {"Accept": "application/json"},
        json: true,
        qs: querystring
    })
}

router.get('/', function (req, res, next) {
    res.json({'test': "success!"})
});

router.get('/weather', function (req, res, next) {
    let {longitude, latitude, timeStep, fields} = req.query;
    if (!fields || fields === "all") {
        fields = WEATHER_FIELDS.join(',')
    }
    getWeather(longitude, latitude, timeStep, fields).then(data => {
        data = handleData(data)
        res.json(data.intervals)
    }).catch(error => {
        return res.json({'error': 'api limit'})
    })

});

router.get("/autocomplete", function (req, res) {
    let {input} = req.query;
    if (input)
        autoComplete(input).then(result => {
            let results = [];
            result.predictions.forEach(item => {
                results.push({
                    description: item.description,
                    state: STATE[item.terms[1].value],
                    city: item.terms[0].value,
                    street: item.terms[0].value
                })
            })
            res.json(results)
        }).catch(error => {
            res.json({
                error,
                url: `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${input}&types=(cities)&components=country:us&key=${GOOGLEMAP_APIKEY}`
            })
        })
    else
        res.json({'error': 'input is null'})
})
router.get('/location', function (req, res) {
    let {street, city, state} = req.query;
    getLocation(street, city, state).then(data => {
        let location = data["results"][0]["geometry"]["location"];
        let formatAddress = data["results"][0]["formatted_address"];
        return res.json({lat: location['lat'], lng: location['lng'], formatAddress})
    }).catch(error => {
        return res.json(error)
    })
})
module.exports = router;
