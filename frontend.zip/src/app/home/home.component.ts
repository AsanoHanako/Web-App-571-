import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import highchartsMore from 'highcharts/highcharts-more'
import WindBarb from 'highcharts/modules/windbarb'
import {HttpClient} from "@angular/common/http";
import * as Highcharts from 'highcharts';
import {ActivatedRoute} from '@angular/router';
import {SearchService} from "../search.service";

const HOST = "https://warm-height-331414.uc.r.appspot.com";


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  lat = 40.7127753;
  lng = -74.0059728;
  error = false;
  isFavorite = false;
  minMaxChart: any = Highcharts;
  minMaxChartOptions: any;
  shareText: any = "";
  meteogramChart: any = Highcharts;
  meteogramChartOption: any;
  dailyWeatherData: any = [];
  hourWeatherData: any = [];
  selectedWeather: any;
  isLoading: any = false;
  favoriteList: any = [];
  searchServiceItem: any;
  storeSearchServiceItem: any
  currentSearchPlace: any = {};

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public http: HttpClient,
    private searchService: SearchService
  ) {
    highchartsMore(this.minMaxChart);
    WindBarb(this.meteogramChart);
    this.favoriteList = this.getFavoriteList();
  }

  initMap() {
    let mapEle: any = document.getElementById('map');
    const myLatLng: any = {lat: this.currentSearchPlace.lat, lng: this.currentSearchPlace.lon};
    console.log(myLatLng)
    let map = new google.maps.Map(mapEle, {
      zoom: 15,
      center: {lat: this.currentSearchPlace.lat, lng: this.currentSearchPlace.lon}
    });
    new google.maps.Marker({
      position: myLatLng,
      map,
      title: this.currentSearchPlace.id,
    });

  }

  getFavoriteList() {
    let favList = localStorage.getItem("fav_list");
    if (favList)
      return JSON.parse(favList)
    else return [];
  }

  checkIsFavorite() {
    let id = `${this.currentSearchPlace.city},${this.currentSearchPlace.state}`;
    let find = this.favoriteList.filter((item: any) => {
      return item.id === id;
    })
    return find.length > 0
  }

  addOrRemoveFavorite() {
    let id = `${this.currentSearchPlace.city},${this.currentSearchPlace.state}`;
    if (this.isFavorite) {
      this.favoriteList = this.favoriteList.filter((item: any) => {
        return item.id !== id;
      })
      this.isFavorite = false;
    } else {
      this.favoriteList.push(this.currentSearchPlace)
      this.isFavorite = true;
    }
    localStorage.setItem('fav_list', JSON.stringify(this.favoriteList))
  }

  ngOnInit(): void {
    this.searchServiceItem = this.searchService.search$.subscribe((value: any) => {
      if (value.action === "query") {
        this.isLoading = true;
        if (value.currentLocation) {
          this.getCurrentGeoCode().subscribe((response: any) => {
            this.currentSearchPlace.city = response.city
            this.currentSearchPlace.state = response.country;
            this.currentSearchPlace.lat = response.lat;
            this.currentSearchPlace.lon = response.lon;
            this.currentSearchPlace.id = `${this.currentSearchPlace.city},${this.currentSearchPlace.state}`;
            this.isFavorite = this.checkIsFavorite();
            this.getWeatherData(response.lat, response.lon);
          })
        } else {
          this.getGeoCodeByAddress(value).subscribe((resp: any) => {
            this.currentSearchPlace.city = value.city
            this.currentSearchPlace.state = value.state;
            this.currentSearchPlace.lat = resp.lat;
            this.currentSearchPlace.lon = resp.lng;
            this.currentSearchPlace.id = `${this.currentSearchPlace.city},${this.currentSearchPlace.state}`;
            this.isFavorite = this.checkIsFavorite();
            this.getWeatherData(resp.lat, resp.lng);
          })
        }
      } else if (value.action == "store") {
        this.storeSearchServiceItem = this.searchService.store$.subscribe((data: any) => {
          if (data) {
            this.currentSearchPlace = data.current;
            this.dailyWeatherData = data.daily;
            this.minMaxChartOptions = this.getMinMaxChartOption(data.daily);
            this.hourWeatherData = data.hour;
            this.meteogramChartOption = this.getMeteogramOption(data.hour);
            this.isFavorite = this.checkIsFavorite();
          }
        })
      } else if (value.action == "fav_search") {
        this.isLoading = true;
        this.currentSearchPlace = value;
        this.isFavorite = true;
        this.getWeatherData(value.lat, value.lon);
      }
    });

  }

  ngOnDestroy() {
    this.searchServiceItem.unsubscribe();
    if (this.storeSearchServiceItem)
      this.storeSearchServiceItem.unsubscribe();
  }

  getMinMaxChartOption(dailyWeatherData: any) {
    const arr = []
    for (let item of dailyWeatherData) {
      arr.push([item.timestamp, item.values.temperatureMin, item.values.temperatureMax])
    }
    return {
      chart: {
        type: 'arearange',
        zoomType: 'x'
      },
      title: {
        text: 'Temperature Ranges (Min, Max)'
      },
      plotOptions: {
        series: {
          fillColor: {
            linearGradient: [0, 0, 0, 400],
            stops: [
              [0, '#F5AB3B'],
              [1, Highcharts.color(this.minMaxChart.getOptions().colors[0]).setOpacity(0).get('rgba')]
            ]
          }
        }
      },
      xAxis: {
        type: 'datetime',
        crosshair: true
      },
      yAxis: {
        title: {
          text: null
        }
      },
      tooltip: {
        shared: true,
        valueSuffix: '℉'
      },
      legend: {
        enabled: false
      },
      series: [{
        name: 'Temperatures',
        data: arr
      }]
    }
  }

  getMeteogramOption(hourWeatherData: any) {
    let temperature: any = [], pressure: any = [], wind: any = [], humility: any = [];
    let i = 0;
    for (let item of hourWeatherData) {
      temperature.push([item.timestamp, item.values.temperature])
      pressure.push([item.timestamp, Math.floor(item.values.pressureSeaLevel)])
      humility.push([item.timestamp, item.values.humidity])
      if (i % 3 == 0)
        wind.push([item.timestamp, item.values.windSpeed, item.values.windDirection])
      i++;
    }
    return {
      chart: {
        marginBottom: 70,
        marginRight: 40,
        marginTop: 50,
        plotBorderWidth: 1,
        height: 400,
        alignTicks: false,
        scrollablePlotArea: {
          minWidth: 720
        }
      },

      defs: {
        patterns: [{
          id: 'precipitation-error',
          path: {
            d: [
              'M', 3.3, 0, 'L', -6.7, 10,
              'M', 6.7, 0, 'L', -3.3, 10,
              'M', 10, 0, 'L', 0, 10,
              'M', 13.3, 0, 'L', 3.3, 10,
              'M', 16.7, 0, 'L', 6.7, 10
            ].join(' '),
            stroke: '#68CFE8',
            strokeWidth: 1
          }
        }]
      },

      title: {
        text: 'Hourly Weather ( For Next 5 Days )',
      },

      credits: {
        text: 'Forecast from '
      },

      tooltip: {
        shared: true,
        useHTML: true,
        headerFormat:
          '<small>{point.x:%A, %b %e, %H:%M} - {point.point.to:%H:%M}</small><br>' +
          '<b>{point.point.symbolName}</b><br>'
      },
      xAxis: [{ // Bottom X axis
        type: 'datetime',
        tickInterval: 4 * 36e5, // two hours
        minorTickInterval: 2 * 36e5, // one hour
        tickLength: 0,
        gridLineWidth: 1,
        gridLineColor: 'rgba(128, 128, 128, 0.1)',
        startOnTick: false,
        endOnTick: false,
        minPadding: 0,
        maxPadding: 0,
        offset: 30,
        showLastLabel: true,
        labels: {
          format: '{value:%H}'
        },
        crosshair: true
      }, { // Top X axis
        linkedTo: 0,
        type: 'datetime',
        tickInterval: 24 * 3600 * 1000,
        labels: {
          format: '{value:<span style="font-size: 12px; font-weight: bold">%a</span> %b %e}',
          align: 'left',
          x: 3,
          y: -5
        },
        opposite: true,
        tickLength: 20,
        gridLineWidth: 1
      }],

      yAxis: [
        { // temperature axis
          title: {
            text: null
          },
          labels: {
            format: '{value}°',
            style: {
              fontSize: '10px'
            },
            x: -3
          },
          plotLines: [{ // zero plane
            value: 0,
            color: '#BBBBBB',
            width: 1,
            zIndex: 2
          }],
          maxPadding: 0.3,
          minRange: 8,
          tickInterval: 1,
          gridLineColor: 'rgba(128, 128, 128, 0.1)'

        }, { // precipitation axis
          title: {
            text: null
          },
          labels: {
            enabled: false
          },
          gridLineWidth: 0,
          tickLength: 0,
          minRange: 10,
          min: 0

        }, { // Air pressure
          allowDecimals: false,
          title: { // Title on top of axis
            text: 'hPa',
            offset: 0,
            align: 'high',
            rotation: 0,
            style: {
              fontSize: '10px',
              color: this.meteogramChart.getOptions().colors[0]
            },
            textAlign: 'left',
            x: 3
          },
          labels: {
            style: {
              fontSize: '8px',
              color: this.meteogramChart.getOptions().colors[1]
            },
            y: 2,
            x: 3
          },
          gridLineWidth: 0,
          opposite: true,
          showLastLabel: false
        }],

      legend: {
        enabled: false
      },

      plotOptions: {
        series: {
          pointPlacement: 'between'
        }
      },
      series: [
        {
          name: 'Temperature',
          type: 'spline',
          data: temperature,
          marker: {
            enabled: false,
            states: {
              hover: {
                enabled: true
              }
            }
          },
          tooltip: {
            pointFormat: '<span style="color:{point.color}">\u25CF</span> ' +
              '{series.name}: <b>{point.y}℉</b><br/>'
          },
          zIndex: 1,
          color: '#FF3333',
          negativeColor: '#48AFE8'
        },
        {
          name: 'Humility',
          type: 'column',
          color: '#96cdfa',
          yAxis: 1,
          data: humility,
          groupPadding: 0,
          pointPadding: 0,
          grouping: false,
          dataLabels: {
            filter: {
              operator: '>',
              property: 'y',
              value: 0
            },
            style: {
              fontSize: '8px',
              color: 'gray'
            }
          },
          tooltip: {
            valueSuffix: '%'
          }
        },
        {
          name: 'Air pressure',
          color: "#ff9900",
          data: pressure,
          marker: {
            enabled: false
          },
          shadow: false,
          tooltip: {
            valueSuffix: ' inHg'
          },
          dashStyle: 'shortdot',
          yAxis: 2
        },
        {
          name: 'Wind',
          id: 'windbarb',
          type: 'windbarb',
          data: wind,
          color: '#FF3333',
          lineWidth: 1.5,
          vectorLength: 18,
          yOffset: -15,
          tooltip: {
            valueSuffix: ' m/s'
          }
        }]
    }
  }

  results() {
    this.router.navigateByUrl("home")
  }

  go_favorites() {
    this.router.navigateByUrl("favs")
  }

  getCurrentGeoCode() {
    const url = "http://ip-api.com/json";
    return this.http.get(url)
  }

  getGeoCodeByAddress(form: any) {
    const url = `${HOST}/location?street=${form.street}&state=${form.state}&city=${form.city}`;
    return this.http.get(url)
  }

  getShareMessage() {
    this.shareText = `The temperature in ${this.currentSearchPlace.city}, ${this.currentSearchPlace.state} on ${this.selectedWeather.startTime} is ${this.selectedWeather.values.temperature}°F. The weather conditions are ${this.selectedWeather.weatherStatus}`
  }

  getWeatherData(lat: any, lon: any) {
    this.error = false;
    const data: any = {};
    this.getDailyWeatherData(lat, lon).subscribe((response: any) => {
      if (response.error) {
        this.isLoading = false;
        this.error = true;
      } else {
        this.dailyWeatherData = response;
        this.minMaxChartOptions = this.getMinMaxChartOption(response);
        data['daily'] = response;
        this.getHourWeatherData(lat, lon).subscribe((response_2: any) => {
          data['hour'] = response_2;
          data['current'] = this.currentSearchPlace;
          this.hourWeatherData = response_2;
          this.meteogramChartOption = this.getMeteogramOption(response_2);
          this.isLoading = false;
          this.searchService.withoutQuery(data);
        })
      }
    })
  }

  getHourWeatherData(lat: any, lon: any) {
    const hoursUrl = `${HOST}/weather?longitude=${lon}&latitude=${lat}&fields=temperature,humidity,windSpeed,pressureSeaLevel,windDirection&timeStep=1h`;
    return this.http.get(hoursUrl)
  }

  getDailyWeatherData(lat: any, lon: any) {
    const dailyUrl = `${HOST}/weather?longitude=${lon}&latitude=${lat}`;
    return this.http.get(dailyUrl)
  }


}
