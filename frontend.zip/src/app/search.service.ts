import {Injectable} from '@angular/core';
import {BehaviorSubject} from "rxjs"

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  constructor() {
  }

  searchData: any = {};
  search$ = new BehaviorSubject<Boolean>(this.searchData);
  storeData: any = false;
  store$ = new BehaviorSubject<Boolean>(this.storeData);

  query(data: any) {
    this.searchData = data;
    this.search$.next(this.searchData);
  }

  withoutQuery(data: any) {
    this.storeData = data;
    this.store$.next(this.storeData);
  }

}
