import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {SearchService} from "../search.service";

@Component({
  selector: 'app-favs',
  templateUrl: './favs.component.html',
  styleUrls: ['./favs.component.css']
})
export class FavoritesComponent implements OnInit {
  searchServiceManager: any;
  favList: any = [];

  constructor(private router: Router, private searchService: SearchService) {
    this.favList = this.getFavoriteList()
  }

  getFavoriteList() {
    let favList = localStorage.getItem("fav_list");
    if (favList)
      return JSON.parse(favList)
    else return [];
  }

  addOrRemoveFavorite(place: any) {
    this.favList = this.favList.filter((item: any) => {
      return item.id !== place.id;
    })
    localStorage.setItem('fav_list', JSON.stringify(this.favList))
  }

  results() {
    this.searchService.query({'action': 'store'});
    this.router.navigateByUrl("home")

  }

  goFavorites() {
    this.router.navigateByUrl("favs")
  }

  goSearch(place: any) {
    place['action'] = "fav_search";
    this.searchService.query(place);
    this.router.navigateByUrl("home")
  }

  ngOnInit(): void {
  }

}
